package com.ben.quiz.domain.dto.result;

public class FacultyInformDto {

    private int iFacultyInformationPk;
    private String strFacultyInformationShortName;
    private String strFacultyInformationFullName;
    private Integer iFacultyInformationPkEk;



    public int getiFacultyInformationPk() {
        return iFacultyInformationPk;
    }

    public void setiFacultyInformationPk(int iFacultyInformationPk) {
        this.iFacultyInformationPk = iFacultyInformationPk;
    }

    public String getStrFacultyInformationShortName() {
        return strFacultyInformationShortName;
    }

    public void setStrFacultyInformationShortName(String strFacultyInformationShortName) {
        this.strFacultyInformationShortName = strFacultyInformationShortName;
    }

    public String getStrFacultyInformationFullName() {
        return strFacultyInformationFullName;
    }

    public void setStrFacultyInformationFullName(String strFacultyInformationFullName) {
        this.strFacultyInformationFullName = strFacultyInformationFullName;
    }

    public Integer getiFacultyInformationPkEk() {
        return iFacultyInformationPkEk;
    }

    public void setiFacultyInformationPkEk(Integer iFacultyInformationPkEk) {
        this.iFacultyInformationPkEk = iFacultyInformationPkEk;
    }
}
