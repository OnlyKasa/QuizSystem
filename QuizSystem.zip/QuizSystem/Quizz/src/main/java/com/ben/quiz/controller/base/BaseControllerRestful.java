package com.ben.quiz.controller.base;

/**
 * Restful controller base class for project
 *
 * @author ben
 *
 */
public class BaseControllerRestful extends BaseController {
}
