package com.ben.quiz.domain.model;

import javax.persistence.MappedSuperclass;

/**
 * @author LaurentiuM
 * @version createdOn: 12/20/17
 */
@MappedSuperclass
public abstract class BaseEntity {
}